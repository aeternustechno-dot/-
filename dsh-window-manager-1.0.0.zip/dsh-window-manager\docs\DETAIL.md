# 多窗口插件：设计与边界

## 它到底做什么

Harness 的一个窗口只能呈现一个"当前会话"。想同时推进两条互不相干的工作线，就得在同一个窗口里来回切换，切换会打断上下文、抢焦点、覆盖草稿。这个插件把"窗口"变成可以按需增加、有上限、可回收的资源：智能体说一句"再开一个窗口跑这件事"，桌面上就多一个独立窗口，各自停在自己的会话上。

## 三条要求怎么落地的

### 1. 同时打开多个窗口

每个窗口是一个**独立的浏览器进程**（Chrome 或 Edge，`--app=<url>` 模式，没有地址栏），带自己的 `--user-data-dir`。

`WindowManager` 维护槽位 `w1..wN`，每个槽位绑定一个固定的 profile 目录 `$DSH_HOME/window-manager/profiles/wN`。槽位与 profile 一一对应且持久：关掉 `w1` 再开 `w1`，那个 profile 里的 localStorage 还在，窗口会回到它上次的会话。

关窗优先走该窗口的调试端口（`Browser.close`），其次 `PUT /json/close/<targetId>`，再其次 `taskkill /PID <pid> /T /F`（Windows，杀进程树避免孤儿），最后按 `--user-data-dir` 反查进程强杀。

### 存活判定（这里踩过一个坑）

最初用"启动器进程还在不在"判断窗口是否存活，结果 `window_open` 返回成功后 `window_list` 立刻变空——因为 Chrome 会把 `--app=` 窗口**交接**给已有浏览器进程，启动器随即退出。现在改用三级判定：

1. 该窗口的调试端口是否还应答（`--remote-debugging-port=0` 让 Chrome 把实际端口写进 `<profile>/DevToolsActivePort`）；
2. 进程号是否还活着；
3. profile 里的 `Default/History` 是否被独占（运行中的 Chrome 会锁这个文件，`EBUSY`/`EPERM`/`EACCES`）。

插件每 2.5 秒巡检一次，`exit` 事件只触发巡检而不直接回收槽位。另外 `open()` 会先看同一个 profile 是否已有遗留窗口：有端口就把它导航到本次地址（接管），没有端口就按 profile 反查进程清掉再干净重开。

### 2. 每个窗口独立打开会话

"独立"由两层保证：

- **天然隔离**：不同 `--user-data-dir` 的 localStorage 完全分开，而 DSH 客户端把"当前会话"存在 localStorage（`dsh.sessions.current`）。所以两个窗口各自记各自的当前会话，不需要任何 hack。
- **显式指定**：`window_open` 接受 `sessionId`，把它写进窗口 URL 的 hash（`#w=w1&s=<sessionId>`）。窗口里的 `client.js` 读到 `s=` 后调 `uiWorkspace.openSession(sessionId)` 切过去。

hash 而不是 query，是因为首次访问带 token 的地址时 Host 会 `303` 跳到 `./` 并种认证 cookie——query 在跳转中丢失，fragment 不会。

### 3. 最大窗口数可配置

设置页里 1–12，默认 4，存在 Loader 条目的 `config` 里（经 `configEditor` 写入，插件从不直接改 profile 的 `cordis.patch.yml`）。

上限是**硬拒绝**：达到上限时 `window_open` 返回失败并提示"请先关闭一个窗口，或在设置里调大「最大窗口数」"，不排队、不悄悄复用、不静默失败。

## 右键菜单：打开文件与在新窗口预览

Harness 自带的文件右键菜单提供「在侧边栏打开 / 在浮窗中打开 / 在文件夹显示 / 用某应用打开 / 复制文件路径 / 下载」，没有单纯的"用默认程序打开"。本插件补上这一项，同时给出新窗口预览的入口。

菜单注册走 `ctx.contextMenus.register({ id, target: 'file', order: 700, resolve })`，`resolve` 收到 `ContextMenuTargetMap['file']`，即 `{ sessionId, path, line? }`（`path` 是相对工作区路径）。

**「打开」的实现不自己 spawn 进程。** Host 已经有一条现成通道 `session.openWorkspacePath`（Host Service `sessionController` 的 `@Remote`）：

- 请求 `{ action?: 'reveal', application?: string, path: string }`；省略 `action` 就是用默认程序打开，省略 `application` 就是系统默认；
- 返回 `{ opened: true }`，Remote 结果形如 `{ ok: true, value: { opened: true } }`；
- Host 侧先 `verifyDesktopPath`，路径必须能映射回 Host 文件系统，否则抛 `gateway/bad-request`。

所以插件先把菜单给的相对路径经 `remote.workspaceFiles.stat(sessionId, path)` 解析成绝对路径（`result.value.absolutePath`），再交给 `openWorkspacePath({ path })`。这与 Harness 自带 `ui-open-in-app` 的 `OpenInAppPathController.openPath` 是同一条路，行为一致。失败（没有关联程序、Host 拒绝）时 `ctx.contextMenus.notify` 弹「打开失败」。

「在新窗口打开预览」则是 `POST /windows/preview`，参数 `{ sessionId, address, line? }`，`address` 是 `dsh-resource://file/session/<sid>/<path>`；Host 侧把它拼进新窗口 URL 的 hash（`f=`），窗口里的 `client.js` 读到后用 `sidebarRight.openResource` 打开。

> 早先的版本还有一个「取消侧边栏预览」开关（把所有预览都改道到新窗口）。该功能已按用户要求移除：它需要包装 `openResource` 与 `openResourceIn` 两个导航入口，还要改写 localStorage 里保存的布局，副作用面太大。现在预览仍留在侧边栏，右键即可选择是否去新窗口。

## 为什么不是 Electron 原生窗口

这是本插件最关键的约束，值得单独写清楚。

插件运行在 **Host 子进程**（`dsh-desktop-host` 由 Electron 主进程 spawn），`BrowserWindow` 只存在于主进程。打包版主进程里：

- `createWindow()` 只在 `lib/main.js:21465` 被调用一次（主窗口），没有"新建窗口"的产品入口；
- `lib/main.js:20278` 的 `setWindowOpenHandler` 对所有 `window.open` 返回 `{ action: 'deny' }`；
- `lib/main.js:20349` 的 `will-navigate` 把非 `dsh-app:` 且非同源的导航 `preventDefault()` 后丢给系统浏览器；
- `DESKTOP_IPC` / `PLATFORM_IPC` 里没有 createWindow，`PLATFORM_IPC.open` 只接受 `usage` 与 `top-up`；
- `requestSingleInstanceLock()` + `second-instance` 只会聚焦已有窗口，再启动 exe 也开不出第二个窗口。

结论：应用内多窗口在当前 Desktop 架构下不可由插件实现。插件改为拉起独立浏览器进程承载同一个 Web 客户端——窗口是真的独立窗口，会话是真的独立会话，代价是它由 Chrome/Edge 渲染而不是 Electron 主窗口（因此没有 Harness 的自定义标题栏）。

## 认证

窗口地址必须带 Host 的认证 token，token 是**进程级常量**且只有 Host 侧知道。所以地址由主机侧拼：`webServer.getOrigin()` → `connection.authenticatedUrl(origin)`。

首次加载时 Host 的 `authorizeIndex` 见到合法 token，`303` 到 `./` 并种 `dsh-auth-*` cookie（`HttpOnly; SameSite=Strict`，绑定 authority）。此后该 profile 里的后续访问靠 cookie 通过认证。

## 已知边界

- **窗口由外部浏览器渲染**：主题、字体、缩放跟随浏览器，不跟随 Harness 的外观设置。
- **窗口数量按 profile 占用统计**：用户手动关掉窗口后，插件在巡检里回收槽位（最多 2.5 秒延迟）。如果进程被强杀且端口与 profile 锁都已释放，槽位会立即回收；若仍有残留，`window_close` 可以清掉。
- **不跨机器**：窗口指向 `127.0.0.1`，只在本机可用。
