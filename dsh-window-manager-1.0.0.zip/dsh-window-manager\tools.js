/**
 * 智能体工具：开窗、列窗、关窗。
 *
 * 工具只负责"窗口进程"这一层；每个窗口里显示哪个会话由该窗口自己的
 * 客户端（client.js 读 hash）决定，所以这里可以把 sessionId 直接写进 URL。
 *
 * @module dsh-window-manager/tools
 */

import { windowOrigin } from './route.js';

/** 注入到系统提示词的一段说明，避免智能体误用工具。 */
export const PROMPT_TEXT = [
  '多窗口（window_open / window_list / window_close）：',
  '- 用户想同时开几个窗口、并行跑多个会话时，用 window_open 新开窗口。每个窗口是独立的浏览器进程，各自持有独立会话，互不干扰。',
  '- 想让某个窗口直接打开到指定会话时，把会话 ID 传给 window_open 的 sessionId。',
  '- 当前窗口清单用 window_list 查；关窗用 window_close（省略 id 关全部）。',
  '- 最多能开几个由设置里的「最大窗口数」决定。达到上限时 window_open 会失败并提示调大上限：不要反复重试，把提示原样转达给用户。',
  '- 窗口会一直留在桌面上，直到被关闭或 Harness 退出（若开启「退出时关闭窗口」）。',
].join('\n');

/** 统一的结果渲染。 */
function renderJson(_args, value) {
  return [{ type: 'text', text: JSON.stringify(value, null, 2) }];
}

/**
 * 去掉 undefined（含嵌套）。
 *
 * 工具输出必须是无损 JSON：任何 undefined 都会让整个工具调用失败，
 * 而失败分支里可选字段天然是 undefined，所以统一在这里收敛。
 */
function jsonSafe(value) {
  if (Array.isArray(value)) return value.map(jsonSafe);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [key, item] of Object.entries(value)) {
      if (item === undefined) continue;
      out[key] = jsonSafe(item);
    }
    return out;
  }
  return value;
}

const WINDOW_ITEM = { type: 'object', additionalProperties: true };

/**
 * 注册工具。
 * @param ctx - 插件上下文。
 * @param state - `{ store, windows }`。
 * @returns 清理函数。
 */
export function registerTools(ctx, state) {
  const { store, windows } = state;
  const disposers = [];

  const register = (definition) => {
    const execute = definition.execute;
    disposers.push(
      ctx.tools.register({
        ...definition,
        async execute(args, exec) {
          return jsonSafe(await execute(args, exec));
        },
      }),
    );
  };

  register({
    name: 'window_open',
    description:
      '新开一个 Harness 窗口。每个窗口是独立的浏览器进程、持有独立会话，互不干扰；可用 sessionId 指定该窗口打开哪个会话。超过设置里的「最大窗口数」时会失败。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        sessionId: {
          type: 'string',
          description: '可选：该窗口要打开的会话 ID。省略时窗口使用自己上次的会话。',
        },
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          ok: { type: 'boolean' },
          status: { type: 'string' },
          id: { type: 'string' },
          url: { type: 'string' },
          pid: { type: 'number' },
          browser: { type: 'string' },
          max: { type: 'number' },
          windows: { type: 'array', items: WINDOW_ITEM },
          detail: { type: 'string' },
        },
      },
      render: renderJson,
    },
    isConcurrencySafe: false,
    async execute(args) {
      try {
        const opened = await windows.open({
          baseUrl: windowOrigin(ctx),
          sessionId:
            typeof args?.sessionId === 'string' && args.sessionId.trim()
              ? args.sessionId.trim()
              : undefined,
          config: store.get(),
        });
        return {
          ok: true,
          status: 'opened',
          id: opened.id,
          url: opened.url,
          pid: opened.pid ?? 0,
          browser: opened.browser,
          max: windows.maxWindows,
          windows: windows.list(),
          detail: `已打开窗口 ${opened.id}（${opened.browser}）。`,
        };
      } catch (error) {
        return {
          ok: false,
          status: 'failed',
          detail: error instanceof Error ? error.message : String(error),
        };
      }
    },
  });

  register({
    name: 'window_list',
    description: '列出当前由多窗口插件打开的窗口，以及最大窗口数。',
    parameters: { type: 'object', additionalProperties: false, properties: {} },
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          ok: { type: 'boolean' },
          max: { type: 'number' },
          browser: { type: 'string' },
          windows: { type: 'array', items: WINDOW_ITEM },
        },
      },
      render: renderJson,
    },
    isConcurrencySafe: true,
    async execute() {
      return {
        ok: true,
        max: windows.maxWindows,
        browser: store.get().browser,
        windows: windows.list(),
      };
    },
  });

  register({
    name: 'window_close',
    description: '关闭一个窗口；省略 id 时关闭全部由多窗口插件打开的窗口。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        id: { type: 'string', description: '可选：窗口编号，例如 w1。省略时关闭全部。' },
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
        properties: {
          ok: { type: 'boolean' },
          status: { type: 'string' },
          closed: { type: 'array', items: { type: 'string' } },
          windows: { type: 'array', items: WINDOW_ITEM },
          detail: { type: 'string' },
        },
      },
      render: renderJson,
    },
    isConcurrencySafe: false,
    async execute(args) {
      const id = typeof args?.id === 'string' ? args.id.trim() : '';
      if (id) {
        const result = await windows.close(id);
        if (!result.closed) {
          return {
            ok: false,
            status: result.reason ?? 'not-open',
            closed: [],
            windows: windows.list(),
            detail: `窗口 ${id} 当前没有打开。`,
          };
        }
        return {
          ok: true,
          status: 'closed',
          closed: [id],
          windows: windows.list(),
          detail: `已关闭窗口 ${id}。`,
        };
      }
      const closed = await windows.closeAll();
      return {
        ok: true,
        status: 'closed',
        closed,
        windows: windows.list(),
        detail: closed.length === 0 ? '当前没有打开的窗口。' : `已关闭 ${closed.length} 个窗口。`,
      };
    },
  });

  return () => {
    for (const dispose of disposers.splice(0)) {
      try {
        dispose?.();
      } catch {
        /* 清理失败不影响退出 */
      }
    }
  };
}
