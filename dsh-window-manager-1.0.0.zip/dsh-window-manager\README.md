# 多窗口（dsh-window-manager）

让 Harness 同时打开多个窗口，每个窗口各自持有一个会话，最多能开几个可以配置。

## 它解决什么

Harness 默认只有一个窗口，也就只有一个"当前会话"。想同时跑两件互不相干的事，就得来回切会话、互相打断。这个插件把窗口数量变成可配置的资源：

- **每个窗口独立会话。** 每个窗口是一个独立的浏览器进程，用自己的配置目录（`$DSH_HOME/window-manager/profiles/wN`），localStorage 与"当前会话"天然隔离，不会互相覆盖。
- **最大窗口数可配置。** 设置页里 1–12，默认 4。达到上限后新的开窗请求会被拒绝并提示调大上限，而不是悄悄失败。
- **两个入口。** 侧边栏底部的「新建窗口」按钮给人用；`window_open` / `window_list` / `window_close` 给智能体用。

## 工具

| 工具 | 用途 |
| --- | --- |
| `window_open` | 新开一个窗口，可选 `sessionId` 指定该窗口打开哪个会话 |
| `window_list` | 列出当前打开的窗口（编号、会话、进程号）与上限 |
| `window_close` | 关闭指定窗口；省略 `id` 关全部 |

## 设置页

设置 → 「多窗口」。可以改：

- 最大窗口数（1–12）
- 用 Chrome 还是 Edge 承载窗口
- 新窗口宽度 / 高度
- Harness 退出时是否关闭这些窗口
- 任务栏右键「新建窗口」（Jump List）
- 桌宠右键「新建窗口」（装了 dsh-pet 时）
- 查看并逐个关闭当前打开的窗口

## 右键打开文件

在对话里、侧边栏文件预览里右键任意文件，菜单里会多出两项：

| 菜单项 | 行为 |
| --- | --- |
| 打开 | 用系统的默认程序打开这个文件（等价于在资源管理器里双击） |
| 在新窗口打开预览 | 新开一个 Harness 窗口，在它的侧边栏里预览这个文件 |

「打开」走的是 Harness 自带的 Host 通道（`session.openWorkspacePath`），插件不自己起进程；文件路径先经 `workspaceFiles.stat` 解析成 Host 上的绝对路径再交出去。默认程序没关联、或者 Host 拒绝打开时，会弹一条「打开失败」的提示，不会静默失败。

## 三个入口

| 入口 | 位置 |
| --- | --- |
| 侧边栏按钮 | 左侧栏底部「＋ 新建窗口」 |
| 界面右键 | 右键左侧会话列表的任意会话 →「在新窗口打开」；右键文件 →「打开」/「在新窗口打开预览」 |
| 系统层 | 任务栏/开始菜单右键 Harness 图标 →「新建 Harness 窗口」；右键桌宠 →「新建 Harness 窗口」 |

## 实现说明

**为什么不用 Electron 原生窗口。** 插件运行在 Host 子进程里，`BrowserWindow` 只存在于 Electron 主进程；打包版主进程没有开放"新建窗口"的 IPC，并且把 `window.open` 全部 deny（`lib/main.js:20278`），导航也被 `will-navigate` 限制。所以窗口由插件自己用 `spawn` 拉起独立浏览器进程实现。

**窗口 URL 怎么拿到。** Host 的 Web 服务需要认证 token，token 只有 Host 侧知道，所以窗口地址由插件在主机侧拼好（`connection.authenticatedUrl`），客户端不能自己拼。

**会话标记为什么放 hash。** 首次访问带 token 的地址时，Host 会 `303` 跳到 `./` 并种 cookie；query 会被这次跳转丢掉，fragment 不会。所以窗口编号与会话 ID 都放 `#w=w1&s=<sessionId>`，由 `client.js` 读出来再调 `uiWorkspace.openSession`。

**怎么判断窗口还开着。** 不能看启动器进程号：Chrome 会把 `--app=` 窗口交接给已有进程，然后启动器自己立刻退出。所以每个窗口带 `--remote-debugging-port=0`，实际端口由 Chrome 写进 `<profile>/DevToolsActivePort`；插件定时问 `http://127.0.0.1:<port>/json/version`，另外用"profile 里的 `History` 是否被独占"作为兜底信号。

**怎么关窗口。** 优先连该窗口的调试端口发 `Browser.close`（浏览器自己干净退出），失败再 `PUT /json/close/<targetId>`，再失败才按进程树 `taskkill /T /F`，最后按 `--user-data-dir` 反查进程强杀。
