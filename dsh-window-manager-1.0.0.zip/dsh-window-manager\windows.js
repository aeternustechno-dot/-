/**
 * 窗口管理器：拉起独立的浏览器窗口承载 DSH Web 客户端。
 *
 * 为什么不用 Electron 窗口：插件运行在 Host 子进程里，`BrowserWindow`
 * 只存在于 Electron 主进程；打包版主进程既没有开放"新建窗口"的 IPC，
 * 又把 `window.open` 全部 deny。所以多窗口只能靠外部浏览器进程。
 *
 * 每个窗口独占一个 `--user-data-dir`，因此：
 *   1. 一个窗口 = 一个独立的浏览器进程，窗口数可以精确统计与关闭；
 *   2. 每个窗口的 localStorage / 当前会话天然互不干扰，
 *      "每个窗口独立打开会话" 不需要任何 hack。
 *
 * 存活判定为什么不用子进程 pid：Chrome 启动时会把窗口"交接"给已有的
 * 浏览器进程，然后启动器自己立刻退出。于是 `child.on('exit')` 会在窗口
 * 还开着的时候就触发，按 pid 记槽位必然漏掉真窗口。这里改为给每个窗口
 * 一个 `--remote-debugging-port=0`，从 profile 里的 `DevToolsActivePort`
 * 读出实际端口，用该端口是否还能应答来判定窗口是否活着；关闭也走同一
 * 个端口（CDP `Browser.close`），不依赖那个已经退出的 pid。
 *
 * @module dsh-window-manager/windows
 */

import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const CANDIDATES = {
  chrome: [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ],
  edge: [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  ],
};

/** 默认等调试端口出现的时间。 */
const PORT_WAIT_MS = 15000;

/** 存活巡检间隔。 */
const REAP_INTERVAL_MS = 2500;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** 探测本机可用的浏览器。 */
export function detectBrowsers() {
  const found = [];
  for (const [kind, list] of Object.entries(CANDIDATES)) {
    for (const candidate of list) {
      try {
        if (fs.existsSync(candidate)) {
          found.push({ kind, executable: candidate });
          break;
        }
      } catch {
        /* 权限不足当作不可用 */
      }
    }
  }
  return found;
}

/** 按偏好选浏览器；没有可用浏览器时抛错。 */
export function pickBrowser(preference) {
  const found = detectBrowsers();
  if (preference && preference !== 'auto') {
    const hit = found.find((item) => item.kind === preference);
    if (!hit) {
      throw new Error(
        `没有找到 ${preference === 'edge' ? 'Edge' : 'Chrome'}：请确认已安装，或在设置里换成另一个浏览器。`,
      );
    }
    return hit;
  }
  if (found.length === 0) throw new Error('没有找到 Chrome 或 Edge：请先安装其中之一，或在设置里指定浏览器。');
  return found[0];
}

/** 插件数据目录。 */
export function dataRoot() {
  const base = process.env.DSH_HOME || path.join(os.homedir(), '.dsh');
  const dir = path.join(base, 'window-manager');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/** 读一个调试端点的 `/json/version`；不可达返回 null。 */
async function devToolsVersion(port, timeoutMs = 1500) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`http://127.0.0.1:${port}/json/version`, { signal: controller.signal });
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** 等 profile 里的 `DevToolsActivePort` 出现并读出端口。 */
export async function probeDevToolsPort(profileDir, timeoutMs = PORT_WAIT_MS) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const port = readDevToolsPort(profileDir);
    if (port) return port;
    if (Date.now() >= deadline) return null;
    await sleep(150);
  }
}

/** 同步读一次 `DevToolsActivePort`，没有就返回 null。 */
export function readDevToolsPort(profileDir) {
  try {
    const text = fs.readFileSync(path.join(profileDir, 'DevToolsActivePort'), 'utf8').trim();
    const port = Number(text.split(/\r?\n/)[0]);
    return Number.isFinite(port) && port > 0 ? port : null;
  } catch {
    return null;
  }
}

/** 通过 CDP 让整个浏览器退出。 */
async function closeViaDevTools(port) {
  const version = await devToolsVersion(port);
  if (!version?.webSocketDebuggerUrl) return false;
  let ws;
  try {
    ws = new WebSocket(version.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('连接调试端点超时')), 4000);
      ws.onopen = () => {
        clearTimeout(timer);
        resolve();
      };
      ws.onerror = () => {
        clearTimeout(timer);
        reject(new Error('连接调试端点失败'));
      };
    });
    ws.send(JSON.stringify({ id: 1, method: 'Browser.close', params: {} }));
    await sleep(400);
    return true;
  } catch {
    return false;
  } finally {
    try {
      ws?.close();
    } catch {
      /* 已关闭 */
    }
  }
}

/**
 * 让已经开着的窗口导航到指定地址。
 *
 * 用途：插件重载后槽位表是空的，但上一次的浏览器窗口还开着（profile 被它
 * 占着，再启动只会"交接"给旧进程）。这时不新起进程，而是接管旧窗口并把它
 * 带到本次请求的会话上，避免用户看到一个打不开的槽位。
 */
async function navigateViaDevTools(port, url) {
  let ws;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2000);
    const response = await fetch(`http://127.0.0.1:${port}/json/list`, { signal: controller.signal });
    clearTimeout(timer);
    if (!response.ok) return false;
    const targets = await response.json();
    const page = Array.isArray(targets) ? targets.find((item) => item.type === 'page') : null;
    if (!page?.webSocketDebuggerUrl) return false;
    ws = new WebSocket(page.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      const timer2 = setTimeout(() => reject(new Error('连接页面调试端点超时')), 4000);
      ws.onopen = () => {
        clearTimeout(timer2);
        resolve();
      };
      ws.onerror = () => {
        clearTimeout(timer2);
        reject(new Error('连接页面调试端点失败'));
      };
    });
    ws.send(JSON.stringify({ id: 1, method: 'Page.navigate', params: { url } }));
    await sleep(600);
    return true;
  } catch {
    return false;
  } finally {
    try {
      ws?.close();
    } catch {
      /* 已关闭 */
    }
  }
}

/** 兜底：按页面 target 逐个关闭（`Browser.close` 不可用时）。 */
async function closeTargets(port) {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2000);
    const response = await fetch(`http://127.0.0.1:${port}/json/list`, { signal: controller.signal });
    clearTimeout(timer);
    if (!response.ok) return false;
    const targets = await response.json();
    const pages = Array.isArray(targets) ? targets.filter((item) => item.type === 'page') : [];
    let closed = false;
    for (const page of pages) {
      try {
        await fetch(`http://127.0.0.1:${port}/json/close/${page.id}`, { method: 'PUT' });
        closed = true;
      } catch {
        /* 单个失败继续 */
      }
    }
    return closed;
  } catch {
    return false;
  }
}

/** pid 是否还活着（EPERM 视为活着）。 */
function pidAlive(pid) {
  if (!pid) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === 'EPERM';
  }
}

/**
 * profile 是否被某个浏览器进程占着。
 *
 * Windows 上运行中的 Chrome 会独占 `Default/History`，用独占方式打开失败
 * 就说明它还在用这个 profile。这是"没有调试端口时"判断窗口存活最可靠的
 * 本地信号（比 pid 靠谱：窗口可能已经被交接给别的进程）。
 */
export function profileBusy(profileDir) {
  const target = path.join(profileDir, 'Default', 'History');
  try {
    if (!fs.existsSync(target)) return fs.existsSync(path.join(profileDir, 'lockfile'));
    const handle = fs.openSync(target, 'r+');
    fs.closeSync(handle);
    return false;
  } catch (error) {
    return error?.code === 'EBUSY' || error?.code === 'EPERM' || error?.code === 'EACCES';
  }
}

/** 结束整个进程树：Chrome 会派生子进程，只杀父进程会留下孤儿。 */
function killTree(pid) {
  return new Promise((resolve) => {
    if (!pid) return resolve();
    if (process.platform === 'win32') {
      const killer = spawn('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore' });
      killer.on('exit', () => resolve());
      killer.on('error', () => resolve());
      return;
    }
    try {
      process.kill(-pid, 'SIGTERM');
    } catch {
      try {
        process.kill(pid, 'SIGTERM');
      } catch {
        /* 已经退出 */
      }
    }
    resolve();
  });
}

/**
 * 找到并结束占用某个 profile 的浏览器进程。
 *
 * 只在"profile 被占着但拿不到调试端口"这种罕见情况下用（例如旧版本插件
 * 开的窗口、或用户手动用同一个 profile 启动的浏览器）。命令行里带着
 * `--user-data-dir=<profile>` 的进程就是这个窗口的所有者。
 */
async function killByProfile(profileDir) {
  if (process.platform !== 'win32') return false;
  const script = [
    `$dir = '${profileDir.replace(/'/g, "''")}'`,
    "$procs = Get-CimInstance Win32_Process -Filter \"Name='chrome.exe' or Name='msedge.exe'\" -ErrorAction SilentlyContinue",
    '$hits = @($procs | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($dir) })',
    'foreach ($p in $hits) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }',
    'if ($hits.Count -gt 0) { "killed=$($hits.Count)" } else { "killed=0" }',
  ].join('; ');
  return new Promise((resolve) => {
    const runner = spawn(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { stdio: 'ignore', windowsHide: true },
    );
    runner.on('exit', (code) => resolve(code === 0));
    runner.on('error', () => resolve(false));
  });
}

/** 等 profile 不再被占用。 */
async function waitProfileFree(profileDir, timeoutMs = 6000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (!profileBusy(profileDir)) return true;
    await sleep(200);
  }
  return !profileBusy(profileDir);
}

/**
 * 同步结束所有窗口进程，只在 Host 进程真的要退出时调用。
 *
 * 为什么是同步的：`process.on('exit')` 里不能 await，异步的 taskkill / fetch
 * 都不会再被调度。这里用一次 `spawnSync` 的 PowerShell 把所有 `--user-data-dir`
 * 落在本插件 profiles 目录下的浏览器进程一起收掉。
 *
 * 为什么按目录而不是按槽位：插件热重载后新的实例槽位表是空的，但窗口还开着。
 * 目录是唯一跨实例稳定的标识。
 */
export function killProfilesSync() {
  if (process.platform !== 'win32') return false;
  const root = path.join(dataRoot(), 'profiles');
  let dirs = [];
  try {
    dirs = fs
      .readdirSync(root, { withFileTypes: true })
      .filter((entry) => entry.isDirectory())
      .map((entry) => path.join(root, entry.name));
  } catch {
    return false;
  }
  if (dirs.length === 0) return false;
  const listed = dirs.map((dir) => `'${dir.replace(/'/g, "''")}'`).join(',');
  const script = [
    `$dirs = @(${listed})`,
    "$procs = Get-CimInstance Win32_Process -Filter \"Name='chrome.exe' or Name='msedge.exe'\" -ErrorAction SilentlyContinue",
    '$hits = @($procs | Where-Object { $cl = $_.CommandLine; if (-not $cl) { return $false }; foreach ($d in $dirs) { if ($cl.Contains($d)) { return $true } }; return $false })',
    'foreach ($p in $hits) { try { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }',
  ].join('; ');
  try {
    spawnSync(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { stdio: 'ignore', windowsHide: true, timeout: 8000 },
    );
    return true;
  } catch {
    return false;
  }
}

/** 读一个窗口当前正在显示的地址（含 hash），读不到返回空串。 */
async function currentPageUrl(port, timeoutMs = 1500) {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const response = await fetch(`http://127.0.0.1:${port}/json/list`, { signal: controller.signal });
    clearTimeout(timer);
    if (!response.ok) return '';
    const targets = await response.json();
    const page = Array.isArray(targets) ? targets.find((item) => item.type === 'page') : null;
    return typeof page?.url === 'string' ? page.url : '';
  } catch {
    return '';
  }
}

/** 从窗口地址的 hash 里取 `s=`（会话 id），没有返回 null。 */
function sessionIdOfUrl(url) {
  const hash = String(url ?? '').split('#')[1];
  if (!hash) return null;
  for (const pair of hash.split('&')) {
    const [key, value] = pair.split('=');
    if (key === 's' && value) return decodeURIComponent(value);
  }
  return null;
}

/**
 * 管理一组窗口槽位（w1..wN）。
 *
 * 槽位与 profile 目录一一对应且持久：关掉窗口后再开同一个槽位，
 * 浏览器 profile 里的 localStorage 还在，窗口会回到上次的会话。
 */
export class WindowManager {  #slots = new Map();
  #logger;
  #spawn;
  #probePort;
  #closePort;
  #portWaitMs;
  #reaper = null;
  #max = 4;

  /**
   * @param logger - 可选 logger。
   * @param options.spawn - 可选进程启动器，测试时替换。
   * @param options.probePort - 可选端口探测函数，测试时替换。
   * @param options.closePort - 可选关闭函数，测试时替换。
   * @param options.portWaitMs - 等端口的时间，测试时设为 0 可跳过。
   */
  constructor(logger, options) {
    this.#logger = logger;
    this.#spawn = options?.spawn ?? spawn;
    this.#probePort = options?.probePort ?? probeDevToolsPort;
    this.#closePort = options?.closePort ?? closeViaDevTools;
    this.#portWaitMs = options?.portWaitMs ?? PORT_WAIT_MS;
  }

  get maxWindows() {
    return this.#max;
  }

  /** 设置上限（由配置驱动）。 */
  setMax(value) {
    const next = Number.isFinite(value) ? Math.min(Math.max(Math.floor(value), 1), 12) : 4;
    this.#max = next;
    return next;
  }

  /** 当前窗口快照。 */
  list() {
    const items = [];
    for (const [id, slot] of this.#slots) {
      items.push({
        id,
        sessionId: slot.sessionId ?? null,
        pid: slot.pid ?? null,
        port: slot.port ?? null,
        openedAt: slot.openedAt,
        url: slot.url,
      });
    }
    items.sort((a, b) => a.id.localeCompare(b.id, 'en', { numeric: true }));
    return items;
  }

  /** 空闲槽位 id。 */
  #freeSlot() {
    for (let index = 1; index <= this.#max; index += 1) {
      const id = `w${index}`;
      if (!this.#slots.has(id)) return id;
    }
    return null;
  }

  /** 槽位对应的 profile 目录。 */
  #profileDir(id) {
    const dir = path.join(dataRoot(), 'profiles', id);
    fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  /** 槽位是否还活着：优先问调试端口，没有端口时退回 pid / profile 占用。 */
  async #alive(slot) {
    if (slot.port && (await devToolsVersion(slot.port)) !== null) return true;
    if (pidAlive(slot.pid)) return true;
    if (slot.profile && profileBusy(slot.profile)) return true;
    return false;
  }

  /** 巡检：把已经消失的窗口从槽位表里摘掉。 */
  async reap() {
    const gone = [];
    for (const [id, slot] of this.#slots) {
      if (await this.#alive(slot)) continue;
      this.#slots.delete(id);
      gone.push(id);
    }
    if (this.#slots.size === 0) this.#stopReaper();
    return gone;
  }

  /**
   * 接管上一个插件实例留下的窗口。
   *
   * 为什么需要：插件热重载（改配置、装包、开 HMR）会换掉整个实例，槽位表
   * 跟着清空，但浏览器窗口还开着。不接管的话，`window_list` 会说"没有窗口"，
   * 而实际上用户桌面上摆着几个 —— 更糟的是新开窗口会撞上被占用的 profile。
   *
   * 只认 profile 里 `DevToolsActivePort` 还能应答的窗口；端口没了就说明窗口
   * 真的关了，留给 `reap()` 之外的用户手动清理。
   */
  async adoptAll() {
    let dirs = [];
    try {
      dirs = fs
        .readdirSync(path.join(dataRoot(), 'profiles'), { withFileTypes: true })
        .filter((entry) => entry.isDirectory() && /^w\d+$/.test(entry.name))
        .map((entry) => entry.name);
    } catch {
      return [];
    }
    const adopted = [];
    for (const id of dirs) {
      if (this.#slots.has(id)) continue;
      if (Number(id.slice(1)) > this.#max) continue;
      const profile = path.join(dataRoot(), 'profiles', id);
      const port = readDevToolsPort(profile);
      if (!port || (await devToolsVersion(port)) === null) continue;
      const url = await currentPageUrl(port);
      this.#slots.set(id, {
        id,
        pid: null,
        port,
        profile,
        sessionId: sessionIdOfUrl(url),
        openedAt: Date.now(),
        url,
      });
      adopted.push(id);
    }
    if (this.#slots.size > 0) this.#startReaper();
    return adopted;
  }

  #startReaper() {
    if (this.#reaper) return;
    this.#reaper = setInterval(() => {
      this.reap().catch(() => {});
    }, REAP_INTERVAL_MS);
    this.#reaper.unref?.();
  }

  #stopReaper() {
    if (!this.#reaper) return;
    clearInterval(this.#reaper);
    this.#reaper = null;
  }

  /**
   * 打开一个新窗口。
   * @param {{ baseUrl: string, sessionId?: string, config: object }} input
   *   `baseUrl` 必须是已经带认证 token 的地址（Host 的 `authenticatedUrl` 结果）。
   */
  async open({ baseUrl, sessionId, config, extra }) {
    await this.reap();
    const free = this.#freeSlot();
    if (!free) {
      throw new Error(
        `已经达到窗口上限（${this.#max} 个）：请先关闭一个窗口，或在设置里调大「最大窗口数」。`,
      );
    }
    const browser = pickBrowser(config?.browser);
    const url = buildWindowUrl(baseUrl, free, sessionId, extra);
    const width = clampWidth(config?.windowWidth);
    const height = clampHeight(config?.windowHeight);
    const profile = this.#profileDir(free);

    // 接管遗留窗口：插件重载后槽位表是空的，但上一次的浏览器还占着这个
    // profile。此时再启动只会被交接给旧进程（新进程直接退出），所以先问
    // 旧窗口的调试端口还在不在；在就直接把它带到本次要显示的地址。
    const leftover = readDevToolsPort(profile);
    if (leftover && (await devToolsVersion(leftover)) !== null) {
      const navigated = await navigateViaDevTools(leftover, url);
      const slot = {
        id: free,
        pid: null,
        port: leftover,
        profile,
        sessionId: sessionId ?? null,
        openedAt: Date.now(),
        url,
      };
      this.#slots.set(free, slot);
      this.#startReaper();
      return { id: free, url, pid: null, port: leftover, browser: browser.kind, adopted: navigated };
    }

    // profile 还被某个浏览器占着但拿不到调试端口（旧版本插件开的窗口，
    // 或用户手动用同一 profile 起的浏览器）：直接启动会被它接管然后新进程
    // 立刻退出。这里先按 `--user-data-dir` 找到并结束它，再干净地重开。
    if (profileBusy(profile)) {
      await killByProfile(profile);
      if (!(await waitProfileFree(profile))) {
        throw new Error(
          `窗口槽位 ${free} 的浏览器 profile 仍被占用：请手动关掉对应的浏览器窗口后重试。`,
        );
      }
    }

    // 上一次运行留下的端口记录会让我们误判"已经开着"，先删掉。
    try {
      fs.rmSync(path.join(profile, 'DevToolsActivePort'), { force: true });
    } catch {
      /* 删不掉就算了 */
    }

    const args = [
      `--app=${url}`,
      `--user-data-dir=${profile}`,
      '--remote-debugging-port=0',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-background-mode',
      '--disable-session-crashed-bubble',
      '--disable-features=Translate,MediaRouter',
      `--window-size=${width},${height}`,
    ];

    const child = this.#spawn(browser.executable, args, {
      detached: true,
      stdio: 'ignore',
      windowsHide: false,
    });
    child.unref?.();

    const port = this.#portWaitMs > 0 ? await this.#probePort(profile, this.#portWaitMs) : null;
    const slot = {
      id: free,
      pid: child.pid ?? null,
      port,
      profile,
      sessionId: sessionId ?? null,
      openedAt: Date.now(),
      url,
    };
    this.#slots.set(free, slot);
    this.#startReaper();

    // 启动器退出不代表窗口关闭（Chrome 会把窗口交接给别的进程），
    // 所以这里只触发一次巡检，不直接删槽位。
    child.on?.('exit', () => {
      this.reap().catch(() => {});
    });
    child.on?.('error', (error) => {
      if (this.#slots.get(free) === slot) this.#slots.delete(free);
      this.#logger?.warn?.(`window-manager: 启动浏览器失败：${error?.message ?? error}`);
    });

    if (!port && !pidAlive(child.pid) && !profileBusy(profile)) {
      this.#slots.delete(free);
      if (this.#slots.size === 0) this.#stopReaper();
      throw new Error(`窗口启动失败：${browser.kind} 进程立即退出了，请检查浏览器是否可用。`);
    }

    return { id: free, url, pid: slot.pid, port, browser: browser.kind };
  }

  /** 关闭一个窗口（连同它的进程树）。 */
  async close(id) {
    const slot = this.#slots.get(id);
    if (!slot) return { closed: false, reason: 'not-open' };

    let requested = false;
    if (slot.port) {
      requested = await this.#closePort(slot.port);
      if (!requested) requested = await closeTargets(slot.port);
    }
    if (!requested && slot.pid) await killTree(slot.pid);
    if (!requested && slot.profile) await killByProfile(slot.profile);

    // 等窗口真的消失，避免"看起来关了其实还开着"。
    const deadline = Date.now() + 5000;
    while (Date.now() < deadline) {
      if (!(await this.#alive(slot))) {
        this.#slots.delete(id);
        if (this.#slots.size === 0) this.#stopReaper();
        return { closed: true };
      }
      await sleep(200);
    }
    // 端口可能已经失效，但 profile 还占着：再按 profile 收一次。
    if (slot.profile && profileBusy(slot.profile)) {
      await killByProfile(slot.profile);
      if (await waitProfileFree(slot.profile, 4000)) {
        this.#slots.delete(id);
        if (this.#slots.size === 0) this.#stopReaper();
        return { closed: true };
      }
    }
    return { closed: false, reason: 'still-running' };
  }

  /** 关闭全部窗口。 */
  async closeAll() {
    const ids = [...this.#slots.keys()];
    for (const id of ids) await this.close(id);
    return ids;
  }
}

/**
 * 组装窗口 URL。
 *
 * `baseUrl` 必须已经带认证 token（Host 的 `authenticatedUrl` 结果），
 * 窗口标记走 hash：浏览器在 303 重定向时会保留 fragment，而 query 会被
 * `location: './'` 丢掉，所以 hash 是唯一能安全穿过认证跳转的载体。
 */
export function buildWindowUrl(baseUrl, id, sessionId, extra) {
  const base = String(baseUrl ?? '').replace(/#.*$/, '');
  const params = [`w=${encodeURIComponent(id)}`];
  if (sessionId) params.push(`s=${encodeURIComponent(sessionId)}`);
  // 额外载荷（如文件预览的 `f=<资源地址>` 与 `l=<行号>`）。
  if (extra && typeof extra === 'object') {
    for (const [key, value] of Object.entries(extra)) {
      if (value === undefined || value === null || value === '') continue;
      params.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
    }
  }
  return `${base}#${params.join('&')}`;
}

function clampWidth(value) {
  return clampSize(value, 1280, 640, 3840);
}

function clampHeight(value) {
  return clampSize(value, 860, 480, 2160);
}

function clampSize(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(Math.max(Math.floor(number), min), max);
}
