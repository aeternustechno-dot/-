/**
 * 配置：默认值、归一化与持久化。
 *
 * 持久化走 configEditor（插件不自己写 cordis.patch.yml）。
 * 本插件不导出 Config schema：字段都是标量，自己归一化即可，
 * 也避免依赖 Harness 内部的 schema 库。
 *
 * @module dsh-window-manager/config
 */

export const name = 'window-manager';

/** 浏览器取值。 */
export const BROWSER_CHOICES = ['auto', 'chrome', 'edge'];

/** 配置默认值。 */
export const DEFAULTS = {
  /** 最大窗口数。 */
  maxWindows: 4,
  /** 浏览器选择。 */
  browser: 'auto',
  /** 新窗口宽度（像素）。 */
  windowWidth: 1280,
  /** 新窗口高度（像素）。 */
  windowHeight: 860,
  /** Harness 退出时是否关闭全部插件窗口。 */
  closeOnExit: true,
  /** 是否把「新建窗口」写进任务栏跳转列表（Jump List）。 */
  enableJumpList: true,
  /** 装了 dsh-pet 时，是否在桌宠右键菜单里加「新建窗口」。 */
  enablePetMenu: true,
};

/** 把任意输入归一化成完整配置。 */
export function normalizeConfig(input) {
  const raw = input && typeof input === 'object' ? input : {};
  const int = (value, fallback, min, max) => {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.min(Math.max(Math.floor(number), min), max);
  };
  const bool = (value, fallback) => (value === undefined ? fallback : value !== false);
  return {
    maxWindows: int(raw.maxWindows, DEFAULTS.maxWindows, 1, 12),
    browser: BROWSER_CHOICES.includes(raw.browser) ? raw.browser : DEFAULTS.browser,
    windowWidth: int(raw.windowWidth, DEFAULTS.windowWidth, 640, 3840),
    windowHeight: int(raw.windowHeight, DEFAULTS.windowHeight, 480, 2160),
    closeOnExit: bool(raw.closeOnExit, DEFAULTS.closeOnExit),
    enableJumpList: bool(raw.enableJumpList, DEFAULTS.enableJumpList),
    enablePetMenu: bool(raw.enablePetMenu, DEFAULTS.enablePetMenu),
  };
}

/**
 * 配置读写门面。
 * @param ctx - 插件上下文。
 */
export function createConfigStore(ctx) {
  let current = normalizeConfig(undefined);

  const entryOf = () => {
    try {
      return ctx.fiber?.entry;
    } catch {
      return undefined;
    }
  };

  return {
    load(raw) {
      current = normalizeConfig(raw);
      return current;
    },
    get() {
      return current;
    },
    snapshot() {
      return { ...current, defaults: DEFAULTS, choices: { browser: BROWSER_CHOICES } };
    },
    /** 保存补丁字段；没有 configEditor 时抛错，绝不假装保存成功。 */
    async save(patch) {
      const editor = ctx.get('configEditor');
      if (!editor || typeof editor.edit !== 'function') {
        throw new Error('配置服务不可用：无法保存窗口管理器设置。');
      }
      const entry = entryOf();
      if (!entry) throw new Error('找不到插件配置条目：无法保存窗口管理器设置。');
      const merged = normalizeConfig({ ...current, ...patch });
      await editor.edit(entry, (raw) => ({
        ...(raw && typeof raw === 'object' ? raw : {}),
        ...merged,
      }));
      current = merged;
      return current;
    },
  };
}
