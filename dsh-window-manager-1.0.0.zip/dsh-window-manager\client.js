/**
 * 客户端半侧：侧边栏「新建窗口」按钮 + 设置页 + 窗口会话恢复。
 *
 * 刻意不 import 任何 Harness Client 包，只用 React 与主题 token，
 * 以免随 DSH 内部包版本变动而失效。
 *
 * 三件事：
 *   1. sidebar.footer.action 放一个「新建窗口」按钮；
 *   2. settings.section 放配置页（最大窗口数、浏览器、窗口尺寸、退出关闭、
 *      预览移到新窗口、跳转列表、桌宠菜单）；
 *   3. 读 URL hash 的 `s=` 把本窗口切到指定会话 —— 每个窗口有独立的
 *      浏览器 profile，所以"独立会话"本身由 localStorage 隔离保证，
 *      hash 只是让 window_open(sessionId) 能精确落到某个会话。
 *
 * 另外两件（都属于"右键快捷方式开新窗口"）：
 *   - 注册 `contextMenus` 的 session / file 目标，右键会话或文件即可开新窗口；
 *   - 开关打开时，把右侧栏的文件预览重定向到新窗口（hash 带 `f=`）。
 */

window.__ModuleLoader__.load({
  id: '@local/dsh-window-manager',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useCallback, useEffect, useMemo, useRef, useState } = React;

    /** 路由前缀，跟随挂载点（DSH 可能挂在子路径下）。 */
    const ROUTE_SEGMENT = '/dsh-window-manager-6193';
    const mountPrefix = (() => {
      try {
        const base = typeof document === 'undefined' ? undefined : document.baseURI;
        if (!base) return '';
        const url = new URL(base);
        if (url.protocol !== 'http:' && url.protocol !== 'https:') return '';
        return url.pathname.replace(/\/+$/, '');
      } catch {
        return '';
      }
    })();
    const ROUTE = mountPrefix + ROUTE_SEGMENT;

    const S = {
      card: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        padding: 4,
        color: 'var(--dsw-alias-label-primary)',
        fontSize: 13,
      },
      hint: { color: 'var(--dsw-alias-label-secondary)', fontSize: 12, lineHeight: 1.6, margin: 0 },
      section: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        padding: 14,
        borderRadius: 10,
        border: '1px solid var(--dsw-alias-border-l1)',
        background: 'var(--dsw-alias-bg-layer-1)',
      },
      sectionTitle: { fontSize: 13, fontWeight: 600, margin: 0 },
      row: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
      label: { display: 'flex', flexDirection: 'column', gap: 2, flex: 1 },
      control: {
        padding: '6px 8px',
        borderRadius: 6,
        border: '1px solid var(--dsw-alias-border-l1)',
        background: 'var(--dsw-alias-bg-base)',
        color: 'var(--dsw-alias-label-primary)',
        fontSize: 12,
        fontFamily: 'inherit',
        outline: 'none',
      },
      toggle: { width: 36, height: 20, flex: '0 0 auto', cursor: 'pointer' },
      footer: { display: 'flex', alignItems: 'center', gap: 12 },
      button: {
        padding: '7px 16px',
        borderRadius: 7,
        border: '1px solid transparent',
        background: 'var(--dsw-alias-brand-primary)',
        color: '#fff',
        fontSize: 12,
        fontWeight: 600,
        cursor: 'pointer',
      },
      buttonGhost: {
        padding: '7px 14px',
        borderRadius: 7,
        border: '1px solid var(--dsw-alias-border-l1)',
        background: 'transparent',
        color: 'var(--dsw-alias-label-primary)',
        fontSize: 12,
        cursor: 'pointer',
      },
      ok: { color: 'var(--dsw-alias-state-success-primary)', fontSize: 12 },
      error: { color: 'var(--dsw-alias-state-error-primary)', fontSize: 12 },
      mono: { fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 11 },
    };

    /** 调本机路由。 */
    async function call(path, init) {
      const response = await fetch(`${ROUTE}${path}`, {
        cache: 'no-store',
        ...init,
        headers: init?.body ? { 'content-type': 'application/json' } : undefined,
      });
      const body = await response.json().catch(() => null);
      if (!response.ok || body?.error) {
        throw new Error(body?.message || body?.error || `HTTP ${response.status}`);
      }
      return body;
    }

    /** 新开一个窗口。 */
    async function openWindow(sessionId) {
      return call('/windows', {
        method: 'POST',
        body: JSON.stringify(sessionId ? { sessionId } : {}),
      });
    }

    /** 新开一个窗口，并让它自己把指定文件预览打开。 */
    async function openPreviewWindow({ sessionId, address, line }) {
      return call('/windows/preview', {
        method: 'POST',
        body: JSON.stringify({ sessionId, address, line }),
      });
    }

    // ---- 文件地址 ------------------------------------------------------

    const FILE_ADDRESS_PREFIX = 'dsh-resource://file/';

    function encodeSegment(segment) {
      return encodeURIComponent(segment).replace(/%3A/gi, ':');
    }

    /** 拼出 Harness 认得的文件资源地址（与 ui-open-in-app 的规则一致）。 */
    function fileAddress(sessionId, filePath) {
      const normalized = String(filePath ?? '')
        .replace(/\\/g, '/')
        .replace(/^(?:\.\/)+/, '');
      const encoded = normalized.split('/').map(encodeSegment).join('/');
      return `${FILE_ADDRESS_PREFIX}session/${encodeSegment(String(sessionId))}/${encoded}`;
    }

    // ---- 侧边栏按钮 ----------------------------------------------------

    const BUTTON_BASE = {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      width: '100%',
      height: 32,
      padding: '0 8px',
      borderRadius: 8,
      border: '1px solid var(--dsw-alias-border-l1)',
      background: 'transparent',
      color: 'var(--dsw-alias-label-secondary)',
      fontSize: 12,
      fontFamily: 'inherit',
      cursor: 'pointer',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
    };

    /** 侧边栏底部的「新建窗口」按钮。 */
    function NewWindowButton({ wide }) {
      const [state, setState] = useState({ kind: 'idle', text: '' });
      const timer = useRef(null);

      useEffect(() => () => clearTimeout(timer.current ?? undefined), []);

      const click = useCallback(async () => {
        setState({ kind: 'busy', text: '' });
        try {
          const result = await openWindow();
          setState({ kind: 'idle', text: '' });
          // 新窗口自己会出现在桌面上，这里只把编号短暂提示一下。
          if (result?.id) {
            setState({ kind: 'ok', text: result.id });
            clearTimeout(timer.current ?? undefined);
            timer.current = setTimeout(() => setState({ kind: 'idle', text: '' }), 2400);
          }
        } catch (error) {
          const text = error instanceof Error ? error.message : String(error);
          setState({ kind: 'error', text });
          clearTimeout(timer.current ?? undefined);
          timer.current = setTimeout(() => setState({ kind: 'idle', text: '' }), 6000);
        }
      }, []);

      const title =
        state.kind === 'error'
          ? state.text
          : state.kind === 'ok'
            ? `已打开窗口 ${state.text}`
            : '新建窗口：独立进程、独立会话';

      const label =
        state.kind === 'error'
          ? '窗口已达上限'
          : state.kind === 'ok'
            ? `已开 ${state.text}`
            : state.kind === 'busy'
              ? '正在打开…'
              : '新建窗口';

      return h(
        'button',
        {
          type: 'button',
          style: {
            ...BUTTON_BASE,
            color:
              state.kind === 'error'
                ? 'var(--dsw-alias-state-error-primary)'
                : state.kind === 'ok'
                  ? 'var(--dsw-alias-state-success-primary)'
                  : BUTTON_BASE.color,
            opacity: state.kind === 'busy' ? 0.6 : 1,
            padding: wide ? '0 8px' : 0,
          },
          title,
          disabled: state.kind === 'busy',
          onClick: () => void click(),
        },
        h('span', { 'aria-hidden': true, style: { fontSize: 15, lineHeight: 1 } }, '＋'),
        wide ? h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' } }, label) : null,
      );
    }

    // ---- 设置页 --------------------------------------------------------

    function Toggle({ title, hint, checked, onChange }) {
      return h(
        'div',
        { style: S.row },
        h(
          'label',
          { style: S.label },
          h('span', { style: { fontWeight: 500 } }, title),
          hint ? h('span', { style: S.hint }, hint) : null,
        ),
        h('input', {
          type: 'checkbox',
          style: S.toggle,
          checked: Boolean(checked),
          onChange: (event) => onChange(event.target.checked),
        }),
      );
    }

    function NumberField({ title, hint, value, min, max, step, onChange }) {
      return h(
        'div',
        { style: S.row },
        h(
          'label',
          { style: S.label },
          h('span', { style: { fontWeight: 500 } }, title),
          hint ? h('span', { style: S.hint }, hint) : null,
        ),
        h('input', {
          type: 'number',
          min,
          max,
          step: step ?? 1,
          style: { ...S.control, width: 100 },
          value,
          onChange: (event) => onChange(event.target.value),
        }),
      );
    }

    function WindowManagerSettings() {
      const [draft, setDraft] = useState(null);
      const [windows, setWindows] = useState([]);
      const [status, setStatus] = useState({ kind: 'idle', text: '' });
      const [saving, setSaving] = useState(false);

      const applyPayload = useCallback((payload) => {
        setDraft({
          maxWindows: Number(payload.maxWindows) || 4,
          browser: payload.browser ?? 'auto',
          windowWidth: Number(payload.windowWidth) || 1280,
          windowHeight: Number(payload.windowHeight) || 860,
          closeOnExit: payload.closeOnExit !== false,
          enableJumpList: payload.enableJumpList !== false,
          enablePetMenu: payload.enablePetMenu !== false,
        });
      }, []);

      const loadWindows = useCallback(async () => {
        try {
          const body = await call('/windows');
          setWindows(Array.isArray(body?.windows) ? body.windows : []);
        } catch {
          setWindows([]);
        }
      }, []);

      const load = useCallback(async () => {
        setStatus({ kind: 'loading', text: '正在读取设置…' });
        try {
          applyPayload(await call('/settings'));
          setStatus({ kind: 'idle', text: '' });
        } catch (error) {
          setStatus({
            kind: 'error',
            text: `读取设置失败：${error instanceof Error ? error.message : String(error)}`,
          });
        }
        await loadWindows();
      }, [applyPayload, loadWindows]);

      useEffect(() => {
        void load();
      }, [load]);

      const patch = useCallback((field, value) => {
        setDraft((current) => (current ? { ...current, [field]: value } : current));
        setStatus({ kind: 'idle', text: '' });
      }, []);

      const save = useCallback(async () => {
        if (!draft) return;
        setSaving(true);
        setStatus({ kind: 'saving', text: '正在保存…' });
        try {
          const body = await call('/settings', {
            method: 'PUT',
            body: JSON.stringify({
              maxWindows: Number(draft.maxWindows) || 4,
              browser: draft.browser,
              windowWidth: Number(draft.windowWidth) || 1280,
              windowHeight: Number(draft.windowHeight) || 860,
              closeOnExit: draft.closeOnExit,
              enableJumpList: draft.enableJumpList,
              enablePetMenu: draft.enablePetMenu,
            }),
          });
          applyPayload(body);
          setStatus({ kind: 'ok', text: '已保存。' });
        } catch (error) {
          setStatus({
            kind: 'error',
            text: `保存失败：${error instanceof Error ? error.message : String(error)}`,
          });
        } finally {
          setSaving(false);
        }
      }, [applyPayload, draft]);

      const openOne = useCallback(async () => {
        setStatus({ kind: 'saving', text: '正在打开窗口…' });
        try {
          const result = await openWindow();
          setStatus({ kind: 'ok', text: `已打开窗口 ${result?.id ?? ''}。` });
          await loadWindows();
        } catch (error) {
          setStatus({
            kind: 'error',
            text: error instanceof Error ? error.message : String(error),
          });
        }
      }, [loadWindows]);

      const closeOne = useCallback(
        async (id) => {
          try {
            await call('/windows/close', { method: 'POST', body: JSON.stringify({ id }) });
            setStatus({ kind: 'ok', text: `已关闭窗口 ${id}。` });
          } catch (error) {
            setStatus({
              kind: 'error',
              text: error instanceof Error ? error.message : String(error),
            });
          }
          await loadWindows();
        },
        [loadWindows],
      );

      const statusText = useMemo(() => {
        if (!status.text) return null;
        const style = status.kind === 'error' ? S.error : status.kind === 'ok' ? S.ok : S.hint;
        return h('span', { style }, status.text);
      }, [status]);

      if (!draft) {
        return h('div', { style: S.card }, h('p', { style: S.hint }, status.text || '正在读取设置…'));
      }

      const rows = windows.length
        ? windows.map((item) =>
            h(
              'div',
              { key: item.id, style: S.row },
              h(
                'span',
                { style: S.mono },
                `${item.id}　${item.sessionId ? `会话 ${item.sessionId}` : '（本窗口自己的会话）'}　PID ${item.pid ?? '—'}`,
              ),
              h(
                'button',
                {
                  type: 'button',
                  style: { ...S.buttonGhost, padding: '4px 10px' },
                  onClick: () => void closeOne(item.id),
                },
                '关闭',
              ),
            ),
          )
        : [h('p', { key: 'empty', style: S.hint }, '当前没有打开的插件窗口。')];

      return h(
        'div',
        { style: S.card },
        h(
          'p',
          { style: S.hint },
          '多窗口插件会让 Harness 同时打开多个独立窗口：每个窗口是一个独立的浏览器进程，各自持有自己的会话，互不干扰。窗口由本机已安装的 Chrome 或 Edge 承载。',
        ),

        h(
          'div',
          { style: S.section },
          h('h3', { style: S.sectionTitle }, '窗口'),
          h(NumberField, {
            title: '最大窗口数',
            hint: '同时最多能打开几个窗口（1–12）。达到上限后智能体的开窗请求会失败并提示调大上限。',
            value: draft.maxWindows,
            min: 1,
            max: 12,
            onChange: (value) => patch('maxWindows', value),
          }),
          h(
            'div',
            { style: S.row },
            h(
              'label',
              { style: S.label },
              h('span', { style: { fontWeight: 500 } }, '浏览器'),
              h('span', { style: S.hint }, '用哪个已安装的浏览器承载窗口。'),
            ),
            h(
              'select',
              {
                style: { ...S.control, width: 140 },
                value: draft.browser,
                onChange: (event) => patch('browser', event.target.value),
              },
              h('option', { value: 'auto' }, '自动选择'),
              h('option', { value: 'chrome' }, 'Chrome'),
              h('option', { value: 'edge' }, 'Edge'),
            ),
          ),
          h(NumberField, {
            title: '新窗口宽度',
            hint: '像素（640–3840）。',
            value: draft.windowWidth,
            min: 640,
            max: 3840,
            onChange: (value) => patch('windowWidth', value),
          }),
          h(NumberField, {
            title: '新窗口高度',
            hint: '像素（480–2160）。',
            value: draft.windowHeight,
            min: 480,
            max: 2160,
            onChange: (value) => patch('windowHeight', value),
          }),
          h(Toggle, {
            title: 'Harness 退出时关闭这些窗口',
            hint: '关闭后，Harness 退出时窗口会留在桌面上。',
            checked: draft.closeOnExit,
            onChange: (value) => patch('closeOnExit', value),
          }),
        ),

        h(
          'div',
          { style: S.section },
          h('h3', { style: S.sectionTitle }, '扩展入口'),
          h(Toggle, {
            title: '任务栏右键「新建窗口」',
            hint: '在任务栏或开始菜单里右键 Harness 图标时，跳转列表里会出现「新建 Harness 窗口」。',
            checked: draft.enableJumpList,
            onChange: (value) => patch('enableJumpList', value),
          }),
          h(Toggle, {
            title: '桌宠右键「新建窗口」',
            hint: '装有 dsh-pet 时，右键桌宠的菜单里会出现「新建 Harness 窗口」；没装则自动忽略。',
            checked: draft.enablePetMenu,
            onChange: (value) => patch('enablePetMenu', value),
          }),
          h(
            'p',
            { style: S.hint },
            '在 Harness 界面里，右键左侧会话列表的任意会话，或右键对话里 / 侧边栏里的文件，也能直接打开或在新窗口打开。',
          ),
        ),

        h(
          'div',
          { style: S.section },
          h(
            'div',
            { style: S.row },
            h('h3', { style: S.sectionTitle }, '当前打开的窗口'),
            h(
              'button',
              { type: 'button', style: { ...S.buttonGhost, padding: '4px 10px' }, onClick: () => void openOne() },
              '新建一个',
            ),
          ),
          ...rows,
        ),

        h(
          'div',
          { style: S.footer },
          h(
            'button',
            { type: 'button', style: { ...S.button, opacity: saving ? 0.6 : 1 }, disabled: saving, onClick: save },
            saving ? '保存中…' : '保存',
          ),
          h(
            'button',
            { type: 'button', style: S.buttonGhost, disabled: saving, onClick: () => void load() },
            '重新读取',
          ),
          statusText,
        ),
      );
    }

    // ---- 会话恢复 + 预览落地 --------------------------------------------

    /** 读 hash 参数。 */
    function hashParam(key) {
      try {
        const hash = String(location.hash || '').replace(/^#/, '');
        if (!hash) return '';
        return new URLSearchParams(hash).get(key) ?? '';
      } catch {
        return '';
      }
    }

    /**
     * 把本窗口切到 URL hash 指定的会话，并在需要时打开 hash 指定的文件预览。
     *
     * 客户端启动时序不确定（会话控制器可能还没就绪），所以重试几次；
     * 失败就静默放弃 —— 窗口仍然可用，只是停在它自己上次的会话。
     */
    function restoreSession(uiWorkspace, sidebarRight) {
      let stop = false;
      let attempts = 0;
      let last = '';
      let previewDone = false;
      // 诊断用：出问题时可以在窗口控制台看 window.__windowManagerRestore。
      const debug = { sessionId: '', attempts: 0, opened: 0, error: '', preview: '' };
      try {
        window.__windowManagerRestore = debug;
      } catch {
        /* 没有 window 就算了 */
      }

      const readSession = () => hashParam('s');
      const readPreview = () => hashParam('f');

      /**
       * 当前界面实际选中的会话。
       *
       * Harness 把「当前会话」存进 localStorage 的 `dsh.sessions.current`，
       * 已经是目标会话时就不用再调 openSession（省得反复打断界面）。
       */
      const currentSession = () => {
        try {
          const raw = localStorage.getItem('dsh.sessions.current');
          if (!raw) return '';
          const parsed = JSON.parse(raw);
          return typeof parsed?.sessionId === 'string' ? parsed.sessionId : '';
        } catch {
          return '';
        }
      };

      const openPreview = () => {
        if (previewDone) return;
        const address = readPreview();
        if (!address) return;
        if (!sidebarRight || typeof sidebarRight.openResource !== 'function') return;
        try {
          const line = Number(hashParam('l'));
          if (Number.isFinite(line) && line > 0) {
            sidebarRight.openResource(address, { params: { line } });
          } else {
            sidebarRight.openResource(address);
          }
          previewDone = true;
          debug.preview = 'opened';
        } catch (error) {
          debug.preview = error instanceof Error ? error.message : String(error);
          /* 资源类型还没注册好，下一轮再试 */
        }
      };

      const attempt = () => {
        if (stop) return;
        const sessionId = readSession();
        if (sessionId && sessionId !== last) {
          last = sessionId;
          attempts = 0;
        }
        debug.sessionId = sessionId;
        if (sessionId && attempts < 40 && currentSession() !== sessionId) {
          attempts += 1;
          debug.attempts = attempts;
          try {
            uiWorkspace.openSession(sessionId);
            debug.opened += 1;
          } catch (error) {
            debug.error = error instanceof Error ? error.message : String(error);
          }
        }
        openPreview();
      };

      const timer = setInterval(attempt, 250);
      const onHashChange = () => {
        attempts = 0;
        previewDone = false;
        attempt();
      };
      if (typeof window !== 'undefined') window.addEventListener('hashchange', onHashChange);

      return () => {
        stop = true;
        clearInterval(timer);
        if (typeof window !== 'undefined') window.removeEventListener('hashchange', onHashChange);
      };
    }

    // ---- 界面内右键菜单 --------------------------------------------------

    /**
     * 右键会话 → 「在新窗口打开」。
     *
     * 这是 Harness 的数据式右键菜单（ctx.contextMenus），target 只能是内置的
     * 六种之一（纯 JS 没法扩展新的 target 类型），这里用 `session`。
     */
    function registerSessionMenu(ctx) {
      const menus = ctx.get('contextMenus');
      if (!menus || typeof menus.register !== 'function') return undefined;
      return menus.register({
        id: 'window-manager.session.open',
        target: 'session',
        order: 700,
        resolve: (target) => [
          {
            id: 'window-manager.open-new-window',
            label: '在新窗口打开',
            separatorBefore: true,
            run: async () => {
              try {
                await openWindow(target?.sessionId);
              } catch (error) {
                menus.notify?.(
                  `新窗口打开失败：${error instanceof Error ? error.message : String(error)}`,
                  false,
                );
              }
            },
          },
        ],
      });
    }

    /** 把任意异常转成能给人看的一句话。 */
    function messageOf(error) {
      return error instanceof Error ? error.message : String(error);
    }

    /**
     * 用系统默认程序打开一个工作区文件。
     *
     * 菜单给的 `target.path` 是相对工作区的路径，先经 `remote.workspaceFiles.stat`
     * 解析成 Host 上的绝对路径（`result.value.absolutePath`），再交给
     * `remote.session.openWorkspacePath` —— 这是 Host 侧现成的通道，
     * 省略 `action` 就是"用默认程序打开"，插件不需要自己 spawn 进程。
     */
    async function openNatively(ctx, sessionId, path) {
      const remote = ctx.remote;
      const opener = remote?.session?.openWorkspacePath;
      if (typeof opener !== 'function') {
        throw new Error('当前环境没有可用的文件打开通道');
      }
      let absolute = String(path ?? '');
      try {
        const stat = await remote.workspaceFiles?.stat?.(sessionId, absolute);
        if (stat?.ok && stat.value?.absolutePath) absolute = stat.value.absolutePath;
      } catch {
        // 解析不出绝对路径就拿原路径试一次：Host 侧还会再解析一遍。
      }
      const result = await opener.call(remote.session, { path: absolute });
      if (!result?.ok) throw new Error('系统拒绝了打开请求');
      return result.value;
    }

    /**
     * 右键文件 → 「打开」/「在新窗口打开预览」。
     *
     * Harness 自带的文件菜单只有「在侧边栏打开 / 在浮窗中打开 / 在文件夹显示 /
     * 用某应用打开 / 复制路径 / 下载」，没有单纯的"用默认程序打开"，
     * 所以这里补一项，并且顺手给出新窗口预览的入口。
     */
    function registerFileMenu(ctx) {
      const menus = ctx.get('contextMenus');
      if (!menus || typeof menus.register !== 'function') return undefined;
      return menus.register({
        id: 'window-manager.file.open',
        target: 'file',
        order: 700,
        resolve: (target) => {
          const sessionId = target?.sessionId;
          const path = target?.path;
          if (!sessionId || !path) return [];
          const actions = [
            {
              id: 'window-manager.open-native',
              label: '打开',
              separatorBefore: true,
              failureLabel: '打开失败',
              run: async () => {
                try {
                  await openNatively(ctx, sessionId, path);
                } catch (error) {
                  menus.notify?.(`打开失败：${messageOf(error)}`, false);
                }
              },
            },
          ];

          const address = fileAddress(sessionId, path);
          if (address) {
            actions.push({
              id: 'window-manager.open-preview-window',
              label: '在新窗口打开预览',
              run: async () => {
                try {
                  await openPreviewWindow({ sessionId, address, line: target?.line });
                } catch (error) {
                  menus.notify?.(`新窗口打开失败：${messageOf(error)}`, false);
                }
              },
            });
          }
          return actions;
        },
      });
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        ctx.slots.inject('sidebar.footer.action', () =>
          ctx.slots.register(
            {
              name: 'sidebar.footer.action',
              id: 'window-manager-new',
              order: 50,
              label: () => '新建窗口',
            },
            NewWindowButton,
          ),
        );

        ctx.slots.inject('settings.section', () =>
          ctx.slots.register(
            {
              name: 'settings.section',
              id: 'window-manager',
              order: 35,
              label: () => '多窗口',
            },
            WindowManagerSettings,
          ),
        );

        // 界面内右键：会话 / 文件。
        //
        // 这些服务在 apply 时可能还没注册好（插件按依赖顺序加载），所以用
        // ctx.inject 等它们出现，而不是 ctx.get 直接取。
        ctx.inject(['contextMenus'], (scoped) => {
          scoped.effect(() => registerSessionMenu(scoped), 'window-manager.menu.session');
        });

        // 文件菜单要调 Host 打开文件，所以把 remote 也声明成依赖：
        // ctx.remote 只有在 inject 声明过之后才可读（否则取属性会抛
        // "cannot get property \"remote.session\" without inject"）。
        ctx.inject(['contextMenus', 'remote', 'remote.session', 'remote.workspaceFiles'], (scoped) => {
          scoped.effect(() => registerFileMenu(scoped), 'window-manager.menu.file');
        });

        // 会话恢复：hash 里的 s= 决定本窗口打开哪个会话，f= 决定要预览的文件。
        ctx.inject(['uiWorkspace', 'sidebarRight'], (scoped) => {
          if (typeof scoped.uiWorkspace?.openSession !== 'function') return;
          scoped.effect(
            () => restoreSession(scoped.uiWorkspace, scoped.sidebarRight),
            'window-manager.session',
          );
        });
      },
    };
  },
});
