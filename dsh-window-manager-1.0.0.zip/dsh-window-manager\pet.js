/**
 * 桌宠（dsh-pet）联动：右键桌宠也能新建窗口。
 *
 * dsh-pet 给第三方插件留了一个「菜单项」通道（进程内存态，不落盘）：
 *   POST   /dsh-pet-7340/menu/item        { owner, labels: string[], target? }
 *   DELETE /dsh-pet-7340/menu/item?owner= 注销
 *   GET    /dsh-pet-7340/menu/events?owner=&wait=  长轮询取点击（wait 上限 1e4）
 *
 * 语义要点（读 dsh-pet 源码确认）：
 *   - 注册是 owner 级整体覆盖，重复注册安全；
 *   - 轮询返回即清空标记，一个 owner 只该有一个消费者；
 *   - 失败也回 HTTP 200，必须看 body.ok；
 *   - dsh-pet 卸载后 owner 就没了，轮询会拿到 `unknown-owner`，此时要重新注册。
 *
 * dsh-pet 是可选依赖：连不上就静默降级，不影响多窗口本身的任何功能。
 *
 * @module dsh-window-manager/pet
 */

/** dsh-pet 的路由前缀。 */
export const PET_ROUTE = '/dsh-pet-7340';

/** 本插件在 dsh-pet 里的 owner 名（也是菜单分组标识）。 */
export const PET_OWNER = 'dsh-window-manager';

/** 菜单项文案（≤32 字符，不能含控制字符）。 */
export const PET_LABEL = '新建 Harness 窗口';

const POLL_WAIT_MS = 10000;
const RETRY_MS = 3000;
/**
 * 两次轮询之间的最小间隔。
 *
 * 正常情况下 `/menu/events?wait=10000` 自己会挂住 10 秒，这个间隔是防御性的：
 * 万一对面立刻返回（代理超时、dsh-pet 版本差异），没有它就会变成忙轮询。
 */
const MIN_POLL_GAP_MS = 500;

/**
 * 桌宠菜单联动。
 *
 * 生命周期由插件 effect 管理：`start()` 起后台循环，`stop()` 停并注销。
 */
export class PetMenu {
  #origin = '';
  #open = null;
  #logger = null;
  #running = false;
  #registered = false;
  #controller = null;
  #timer = null;
  #onOpen = null;
  #generation = 0;
  #retryMs = RETRY_MS;
  #minGapMs = MIN_POLL_GAP_MS;

  constructor(logger, options) {
    this.#logger = logger;
    // 只给测试用：把退避压短，免得冒烟测试要等好几秒。
    this.#retryMs = Number(options?.retryMs) > 0 ? Number(options.retryMs) : RETRY_MS;
    this.#minGapMs =
      Number(options?.minPollGapMs) >= 0 ? Number(options.minPollGapMs) : MIN_POLL_GAP_MS;
  }

  /** 当前是否已成功注册到 dsh-pet。 */
  get registered() {
    return this.#registered;
  }

  /** 当前是否在轮询。 */
  get running() {
    return this.#running;
  }

  #url(sub) {
    return `${this.#origin}${PET_ROUTE}${sub}`;
  }

  /** 注册菜单项；失败返回 false（dsh-pet 没装/没跑）。 */
  async #register() {
    try {
      const response = await fetch(this.#url('/menu/item'), {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ owner: PET_OWNER, labels: [PET_LABEL], target: 'both' }),
        signal: this.#controller?.signal,
      });
      const body = await response.json().catch(() => null);
      if (!response.ok || !body?.ok) {
        this.#registered = false;
        return false;
      }
      this.#registered = true;
      return true;
    } catch {
      this.#registered = false;
      return false;
    }
  }

  /** 注销（幂等；dsh-pet 不在时静默）。 */
  async unregister() {
    this.#registered = false;
    try {
      await fetch(this.#url(`/menu/item?owner=${encodeURIComponent(PET_OWNER)}`), {
        method: 'DELETE',
      });
    } catch {
      /* dsh-pet 不在就算了 */
    }
  }

  /**
   * 起后台循环。
   * @param {object} input
   * @param {string} input.origin - Harness 本地地址（如 `http://127.0.0.1:58341`）。
   * @param {() => Promise<unknown>} input.openWindow - 收到点击时调用。
   */
  start({ origin, openWindow }) {
    const normalized = String(origin ?? '').replace(/\/+$/, '');
    if (!normalized) return;
    // 已经在跑同一个 origin 就不要重启（否则每次保存设置都会打断长轮询）。
    if (this.#running && this.#origin === normalized) {
      this.#onOpen = openWindow;
      return;
    }
    this.stop();
    this.#origin = normalized;
    this.#open = openWindow;
    this.#onOpen = openWindow;
    this.#running = true;
    this.#generation += 1;
    this.#controller = new AbortController();
    void this.#loop(this.#generation);
  }

  stop() {
    this.#running = false;
    this.#registered = false;
    this.#generation += 1;
    if (this.#timer) {
      clearTimeout(this.#timer);
      this.#timer = null;
    }
    this.#controller?.abort();
    this.#controller = null;
  }

  /** 后台循环：注册 → 长轮询 → 处理点击 → 循环；任何失败都退避重试。 */
  async #loop(generation) {
    let failures = 0;
    const stale = () => !this.#running || generation !== this.#generation;
    while (!stale()) {
      const registered = await this.#register();
      if (stale()) return;
      if (!registered) {
        failures += 1;
        await this.#sleep(this.#retryMs);
        continue;
      }
      failures = 0;
      const startedAt = Date.now();
      const clicked = await this.#pollOnce();
      if (stale()) return;
      if (clicked === null) {
        // 网络错误 / owner 被清掉：退避后再注册。
        failures += 1;
        await this.#sleep(Math.min(this.#retryMs * failures, 15000));
        continue;
      }
      if (clicked) {
        try {
          await this.#onOpen?.();
        } catch (error) {
          this.#logger?.warn?.(
            `window-manager: 桌宠菜单开窗失败：${error instanceof Error ? error.message : String(error)}`,
          );
        }
      }
      // 对面秒回时不要变成忙轮询。
      const elapsed = Date.now() - startedAt;
      if (elapsed < this.#minGapMs) await this.#sleep(this.#minGapMs - elapsed);
    }
  }

  /** 一次长轮询：true = 被点，false = 超时无点击，null = 出错。 */
  async #pollOnce() {
    try {
      const response = await fetch(
        this.#url(`/menu/events?owner=${encodeURIComponent(PET_OWNER)}&wait=${POLL_WAIT_MS}`),
        { signal: this.#controller?.signal, cache: 'no-store' },
      );
      const body = await response.json().catch(() => null);
      if (!response.ok || !body) return null;
      if (body.ok === false) {
        // unknown-owner：dsh-pet 重启过，需要重新注册。
        this.#registered = false;
        return null;
      }
      const events = body.events && typeof body.events === 'object' ? body.events : {};
      return Object.values(events).some((value) => value !== null && value !== undefined);
    } catch {
      return null;
    }
  }

  #sleep(ms) {
    return new Promise((resolve) => {
      this.#timer = setTimeout(() => {
        this.#timer = null;
        resolve();
      }, ms);
      this.#timer.unref?.();
    });
  }
}
