/**
 * 本地 HTTP 路由：设置页与客户端脚本用。
 *
 * 窗口 URL 必须带 Host 的认证 token，而 token 只有 Host 侧知道，
 * 所以「拿一个可以打开的窗口地址」这个动作必须经过这里。
 *
 * @module dsh-window-manager/route
 */

export const ROUTE_SEGMENT = '/dsh-window-manager-6193';

const MAX_BODY_BYTES = 64 * 1024;

function sendJson(res, status, value) {
  const body = JSON.stringify(value);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let settled = false;
    const settle = (fn, value) => {
      if (settled) return;
      settled = true;
      fn(value);
    };
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        settle(reject, { code: 'body-too-large' });
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => settle(resolve, Buffer.concat(chunks).toString('utf8')));
    req.on('error', () => settle(reject, { code: 'client-aborted' }));
    req.on('aborted', () => settle(reject, { code: 'client-aborted' }));
  });
}

/**
 * 当前窗口可用的认证地址。
 * @param ctx - 带 connection / webServer 的上下文。
 */
export function windowOrigin(ctx) {
  const connection = ctx.get('connection');
  const webServer = ctx.get('webServer');
  const origin = webServer?.getOrigin?.() ?? '';
  if (!origin) throw new Error('Web 服务不可用：拿不到本机访问地址。');
  if (connection && typeof connection.authenticatedUrl === 'function') {
    return connection.authenticatedUrl(origin);
  }
  return origin;
}

/**
 * 注册路由。
 * @param ctx - 已注入 webServer 的上下文。
 * @param state - { store, windows }
 */
export function registerRoutes(ctx, state) {
  const { store, windows } = state;

  const handler = async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://127.0.0.1');
    const sub = url.pathname.slice(ROUTE_SEGMENT.length) || '/';

    try {
      if (sub === '/settings' && req.method === 'GET') {
        return sendJson(res, 200, store.snapshot());
      }
      if ((sub === '/settings' && (req.method === 'PUT' || req.method === 'POST'))) {
        const text = await readBody(req);
        let parsed;
        try {
          parsed = text.trim() === '' ? {} : JSON.parse(text);
        } catch {
          return sendJson(res, 400, { error: 'invalid-json' });
        }
        const saved = await store.save(parsed);
        windows.setMax(saved.maxWindows);
        state.syncIntegrations?.();
        return sendJson(res, 200, store.snapshot());
      }
      if (sub === '/windows' && req.method === 'GET') {
        return sendJson(res, 200, {
          max: windows.maxWindows,
          windows: windows.list(),
          browser: store.get().browser,
        });
      }
      if (sub === '/windows' && req.method === 'POST') {
        const text = await readBody(req);
        let parsed;
        try {
          parsed = text.trim() === '' ? {} : JSON.parse(text);
        } catch {
          return sendJson(res, 400, { error: 'invalid-json' });
        }
        const opened = await windows.open({
          baseUrl: windowOrigin(ctx),
          sessionId: typeof parsed?.sessionId === 'string' ? parsed.sessionId : undefined,
          config: store.get(),
        });
        return sendJson(res, 200, { ...opened, windows: windows.list(), max: windows.maxWindows });
      }
      if (sub === '/windows/preview' && req.method === 'POST') {
        const text = await readBody(req);
        let parsed;
        try {
          parsed = text.trim() === '' ? {} : JSON.parse(text);
        } catch {
          return sendJson(res, 400, { error: 'invalid-json' });
        }
        const sessionId = typeof parsed?.sessionId === 'string' ? parsed.sessionId : '';
        const address = typeof parsed?.address === 'string' ? parsed.address : '';
        if (!address) return sendJson(res, 400, { error: 'missing-address' });
        const line = Number(parsed?.line);
        const opened = await windows.open({
          baseUrl: windowOrigin(ctx),
          sessionId: sessionId || undefined,
          config: store.get(),
          extra: Number.isFinite(line) && line > 0 ? { f: address, l: line } : { f: address },
        });
        return sendJson(res, 200, { ...opened, windows: windows.list(), max: windows.maxWindows });
      }
      if (sub === '/windows/close' && req.method === 'POST') {
        const text = await readBody(req);
        let parsed;
        try {
          parsed = text.trim() === '' ? {} : JSON.parse(text);
        } catch {
          return sendJson(res, 400, { error: 'invalid-json' });
        }
        const id = typeof parsed?.id === 'string' ? parsed.id : '';
        if (!id) return sendJson(res, 400, { error: 'missing-id' });
        const closed = await windows.close(id);
        return sendJson(res, 200, { ...closed, windows: windows.list() });
      }
      return sendJson(res, 404, { error: 'not-found' });
    } catch (error) {
      const code = error && typeof error === 'object' ? error.code : undefined;
      if (code === 'body-too-large') return sendJson(res, 413, { error: 'body-too-large' });
      if (code === 'client-aborted') return;
      const message = error instanceof Error ? error.message : String(error);
      if (!res.destroyed && !res.writableEnded) sendJson(res, 500, { error: 'failed', message });
    }
  };

  return ctx.webServer.register({ kind: 'prefix', path: ROUTE_SEGMENT, handler });
}
