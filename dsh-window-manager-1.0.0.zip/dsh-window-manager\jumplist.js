/**
 * 任务栏跳转列表（Jump List）：「新建窗口」写进 Harness 图标的右键菜单。
 *
 * 做法：
 *   1. 在插件数据目录写一个 `open-window.vbs` 启动器 —— 它只做一件事：
 *      读同目录的 `endpoint.txt`（当前 Harness 的本地路由地址），POST 一下
 *      让 Host 开一个新窗口。用 VBS 是为了不闪控制台窗口。
 *   2. 用 `ICustomDestinationList` 把「新建 Harness 窗口」写进
 *      `electron.app.DeepSeek Harness` 这个 AppUserModelID 的 Tasks 段。
 *
 * 为什么走 PowerShell + 内联 C#：Jump List 只有 COM 接口，Node 没有原生
 * 绑定。实测要点（踩过很多坑，别改）：
 *   - `AddUserTasks` 收的集合里必须是 **IShellLink** 对象，不能是
 *     `IShellItem`（哪怕指向 .lnk 文件），否则一律 `hr=0x80040F03`。
 *   - `BeginList` 的 riid 要传 `IID_IObjectArray`。
 *   - 写 Jump List 需要 Medium 以上完整性级别；沙箱里的低权限进程会被
 *     拒绝，所以失败只记日志，不影响插件其它功能。
 *
 * @module dsh-window-manager/jumplist
 */

import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

import { dataRoot } from './windows.js';

/** Harness 的 AppUserModelID（从开始菜单快捷方式属性读出，勿改）。 */
export const AUMID = 'electron.app.DeepSeek Harness';

/** 跳转列表里的任务名。 */
export const TASK_TITLE = '新建 Harness 窗口';

const LAUNCHER_NAME = 'open-window.vbs';
const ENDPOINT_NAME = 'endpoint.txt';
const SCRIPT_NAME = 'jumplist.ps1';
const SOURCE_NAME = 'JumpList.cs';
const PARAMS_NAME = 'jumplist-params.json';

/** 内联 C#：只做 Jump List 写入与删除，全 ASCII 以免 PowerShell 编码问题。 */
const CS_SOURCE = `using System;
using System.Runtime.InteropServices;

[ComImport, Guid("77f10cf0-3db5-4966-b520-b7c54fd35ed6")]
public class CDestinationList { }

[ComImport, Guid("92CA9DCD-5622-4BBA-A805-5E9F541BD8C9"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IObjectArray
{
    void GetCount(out uint cObjects);
    void GetAt(uint iIndex, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object ppv);
}

[ComImport, Guid("5632b1a4-e38a-400a-928a-d4cd63230295"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IObjectCollection
{
    void GetCount(out uint cObjects);
    void GetAt(uint iIndex, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object ppv);
    void AddObject([MarshalAs(UnmanagedType.Interface)] object pvObject);
    void AddFromArray([MarshalAs(UnmanagedType.Interface)] IObjectArray poaSource);
    void RemoveObjectAt(uint uiIndex);
    void Clear();
}

[ComImport, Guid("6332debf-87b5-4670-90c0-5e57b408a49e"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface ICustomDestinationList
{
    void SetAppID([MarshalAs(UnmanagedType.LPWStr)] string pszAppID);
    void BeginList(out uint pcMinSlots, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out IObjectArray ppv);
    void AppendCategory([MarshalAs(UnmanagedType.LPWStr)] string pszCategory, [MarshalAs(UnmanagedType.Interface)] IObjectArray poa);
    void AppendKnownCategory(int category);
    void AddUserTasks([MarshalAs(UnmanagedType.Interface)] IObjectArray poa);
    void CommitList();
    void GetRemovedDestinations(ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out IObjectArray ppv);
    void DeleteList([MarshalAs(UnmanagedType.LPWStr)] string pszAppID);
    void AbortList();
}

[ComImport, Guid("2d3468c1-36a7-43b6-ac24-d3f02fd9607a")]
public class CEnumerableObjectCollection { }

[ComImport, Guid("00021401-0000-0000-C000-000000000046")]
public class CShellLink { }

[ComImport, Guid("000214F9-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IShellLinkW
{
    void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder pszFile, int cch, IntPtr pfd, uint fFlags);
    void GetIDList(out IntPtr ppidl);
    void SetIDList(IntPtr pidl);
    void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder pszName, int cch);
    void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);
    void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder pszDir, int cch);
    void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);
    void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder pszArgs, int cch);
    void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);
    void GetHotkey(out short pwHotkey);
    void SetHotkey(short wHotkey);
    void GetShowCmd(out int piShowCmd);
    void SetShowCmd(int iShowCmd);
    void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder pszIconPath, int cch, out int piIcon);
    void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);
    void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, uint dwReserved);
    void Resolve(IntPtr hwnd, uint fFlags);
    void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
}

[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct PROPERTYKEY { public Guid fmtid; public uint pid; }

[StructLayout(LayoutKind.Explicit, Size = 24)]
public struct PROPVARIANT
{
    [FieldOffset(0)] public ushort vt;
    [FieldOffset(8)] public IntPtr pointerValue;
}

[ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IPropertyStore
{
    void GetCount(out uint cProps);
    void GetAt(uint iProp, out PROPERTYKEY pkey);
    void GetValue(ref PROPERTYKEY key, out PROPVARIANT pv);
    void SetValue(ref PROPERTYKEY key, ref PROPVARIANT pv);
    void Commit();
}

public static class DshJumpList
{
    static readonly Guid IID_IObjectArray = new Guid("92CA9DCD-5622-4BBA-A805-5E9F541BD8C9");
    static readonly Guid FMTID_Title = new Guid("F29F85E0-4FF9-1068-AB91-08002B27B3D9");

    static object ShellLink(string target, string args, string title, string icon)
    {
        var link = (IShellLinkW)new CShellLink();
        link.SetPath(target);
        link.SetArguments(args);
        link.SetDescription(title);
        if (!string.IsNullOrEmpty(icon)) link.SetIconLocation(icon, 0);
        var store = (IPropertyStore)link;
        var pv = new PROPVARIANT();
        pv.vt = 31;
        pv.pointerValue = Marshal.StringToCoTaskMemUni(title);
        try
        {
            var key = new PROPERTYKEY { fmtid = FMTID_Title, pid = 2 };
            store.SetValue(ref key, ref pv);
            store.Commit();
        }
        finally { Marshal.FreeCoTaskMem(pv.pointerValue); }
        return (object)link;
    }

    public static void SetTasks(string appId, string target, string args, string title, string icon)
    {
        ICustomDestinationList list = (ICustomDestinationList)new CDestinationList();
        try
        {
            list.SetAppID(appId);
            uint minSlots;
            Guid aiid = IID_IObjectArray;
            IObjectArray removed;
            list.BeginList(out minSlots, ref aiid, out removed);
            var coll = (IObjectCollection)new CEnumerableObjectCollection();
            coll.AddObject(ShellLink(target, args, title, icon));
            list.AddUserTasks((IObjectArray)coll);
            list.CommitList();
        }
        catch
        {
            try { list.AbortList(); } catch { }
            throw;
        }
    }

    public static void Remove(string appId)
    {
        ICustomDestinationList list = (ICustomDestinationList)new CDestinationList();
        list.DeleteList(appId);
    }
}
`;

/** PowerShell 壳：读参数文件 → 编译 C# → 写入或删除。全 ASCII。 */
const PS_SOURCE = `param([Parameter(Mandatory=$true)][string]$ParamsPath)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $ParamsPath
$json = [System.IO.File]::ReadAllText($ParamsPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
$source = [System.IO.File]::ReadAllText((Join-Path $root '${SOURCE_NAME}'), [System.Text.Encoding]::UTF8)
Add-Type -TypeDefinition $source -Language CSharp

if ($json.mode -eq 'remove') {
  [DshJumpList]::Remove($json.appId)
  'ok remove'
  exit 0
}

[DshJumpList]::SetTasks($json.appId, $json.target, $json.args, $json.title, $json.icon)
'ok set'
exit 0
`;

/** VBS 启动器：读 endpoint.txt 并 POST 一下，不弹控制台窗口。 */
const VBS_SOURCE = `Option Explicit
Dim fso, f, url, http, root
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
On Error Resume Next
Set f = fso.OpenTextFile(root & "\\${ENDPOINT_NAME}", 1, False)
If Err.Number <> 0 Then WScript.Quit 1
url = Trim(f.ReadLine)
f.Close
If url = "" Then WScript.Quit 1
Set http = CreateObject("MSXML2.XMLHTTP")
http.Open "POST", url, False
http.setRequestHeader "content-type", "application/json"
http.Send "{}"
WScript.Quit 0
`;

function launcherDir() {
  const dir = dataRoot();
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function powershellPath() {
  const root = process.env.SystemRoot || 'C:\\Windows';
  return path.join(root, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
}

function wscriptPath() {
  const root = process.env.SystemRoot || 'C:\\Windows';
  return path.join(root, 'System32', 'wscript.exe');
}

/** Harness 可执行文件（只用来当图标来源）。 */
export function dshExecutable() {
  const exec = typeof process.execPath === 'string' ? process.execPath : '';
  if (exec && /\.exe$/i.test(exec)) return exec;
  return '';
}

/**
 * 写入（或刷新）启动器与当前路由地址。
 * @param {string} endpointUrl - 形如 `http://127.0.0.1:58341/dsh-window-manager-6193/windows`。
 */
export function writeLauncher(endpointUrl) {
  const dir = launcherDir();
  fs.writeFileSync(path.join(dir, ENDPOINT_NAME), `${endpointUrl}\n`, 'utf8');
  const vbs = path.join(dir, LAUNCHER_NAME);
  if (!fs.existsSync(vbs)) fs.writeFileSync(vbs, VBS_SOURCE, 'utf8');
  return { dir, vbs, endpoint: path.join(dir, ENDPOINT_NAME) };
}

/** 跑一次 PowerShell 脚本；返回 { ok, output }。 */
function runPowerShell(args, timeoutMs = 20000) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(powershellPath(), args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    } catch (error) {
      resolve({ ok: false, output: String(error?.message ?? error) });
      return;
    }
    let out = '';
    let err = '';
    const timer = setTimeout(() => {
      try {
        child.kill();
      } catch {
        /* ignore */
      }
    }, timeoutMs);
    child.stdout?.on('data', (chunk) => {
      out += String(chunk);
    });
    child.stderr?.on('data', (chunk) => {
      err += String(chunk);
    });
    child.on('error', (error) => {
      clearTimeout(timer);
      resolve({ ok: false, output: String(error?.message ?? error) });
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      const text = `${out}${err}`.trim();
      resolve({ ok: code === 0 && /^ok /m.test(out), output: text, code });
    });
  });
}

function ensureScripts(dir) {
  const ps1 = path.join(dir, SCRIPT_NAME);
  fs.writeFileSync(ps1, PS_SOURCE, 'utf8');
  const cs = path.join(dir, SOURCE_NAME);
  fs.writeFileSync(cs, CS_SOURCE, 'utf8');
  return ps1;
}

/**
 * 把「新建窗口」写进任务栏跳转列表。
 * @param {object} input
 * @param {string} input.endpointUrl - 已写入启动器的路由地址。
 * @param {string} [input.title]
 * @param {object} [input.logger]
 */
export async function installJumpList({ endpointUrl, title = TASK_TITLE, logger } = {}) {
  const { dir, vbs } = writeLauncher(endpointUrl);
  const ps1 = ensureScripts(dir);
  const paramsPath = path.join(dir, PARAMS_NAME);
  const icon = dshExecutable();
  const payload = {
    mode: 'set',
    appId: AUMID,
    target: wscriptPath(),
    args: `"${vbs}"`,
    title,
    icon,
  };
  fs.writeFileSync(paramsPath, JSON.stringify(payload, null, 2), 'utf8');
  const result = await runPowerShell([
    '-NoProfile',
    '-NonInteractive',
    '-ExecutionPolicy',
    'Bypass',
    '-File',
    ps1,
    paramsPath,
  ]);
  if (!result.ok) {
    logger?.warn?.(`window-manager: 写入跳转列表失败（不影响其它功能）：${result.output || '未知错误'}`);
  }
  return result;
}

/** 从跳转列表移除（插件停用时）。 */
export async function removeJumpList({ logger } = {}) {
  const dir = launcherDir();
  const ps1 = ensureScripts(dir);
  const paramsPath = path.join(dir, PARAMS_NAME);
  fs.writeFileSync(
    paramsPath,
    JSON.stringify({ mode: 'remove', appId: AUMID }, null, 2),
    'utf8',
  );
  const result = await runPowerShell([
    '-NoProfile',
    '-NonInteractive',
    '-ExecutionPolicy',
    'Bypass',
    '-File',
    ps1,
    paramsPath,
  ]);
  if (!result.ok) {
    logger?.warn?.(`window-manager: 移除跳转列表失败：${result.output || '未知错误'}`);
  }
  return result;
}
