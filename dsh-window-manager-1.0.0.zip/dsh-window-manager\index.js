/**
 * 多窗口插件 —— 主机侧入口。
 *
 * 组成：
 *   - windows.js  窗口进程管理（每个窗口独占一个浏览器 profile）
 *   - config.js   配置归一化与持久化
 *   - route.js    设置页 / 客户端用的本地 HTTP 路由
 *   - tools.js    智能体可调用的 window_open / window_list / window_close
 *   - jumplist.js 任务栏跳转列表（系统层右键「新建窗口」）
 *   - pet.js      装了 dsh-pet 时，右键桌宠「新建窗口」
 *   - client.js   设置页、侧边栏按钮、界面内右键菜单、预览落地
 *
 * 为什么不用 Electron 原生窗口：插件运行在 Host 子进程里，拿不到
 * `BrowserWindow`，而打包版主进程既没有开放新建窗口的 IPC，又把
 * `window.open` 全部 deny。所以多窗口由插件自己拉起独立浏览器进程实现，
 * 顺带天然满足"每个窗口独立会话"。
 *
 * @module dsh-window-manager
 */

import { createConfigStore, name as PLUGIN_NAME } from './config.js';
import { installJumpList, removeJumpList } from './jumplist.js';
import { PetMenu } from './pet.js';
import { ROUTE_SEGMENT, registerRoutes, windowOrigin } from './route.js';
import { PROMPT_TEXT, registerTools } from './tools.js';
import { WindowManager, killProfilesSync } from './windows.js';

export const name = PLUGIN_NAME;

/** tools 是硬依赖；webServer 按需注入，缺失时只是没有设置页。 */
export const inject = ['tools'];

/** 已经挂过进程级退出钩子的进程（热重载会多次 apply，只能挂一次）。 */
const EXIT_HOOK = Symbol.for('dsh-window-manager.exit-hook');

/**
 * 插件入口。
 * @param ctx - 插件上下文。
 * @param config - Loader 传入的配置行（可能是空对象）。
 */
export function apply(ctx, config) {
  const store = createConfigStore(ctx);
  const initial = store.load(config);

  const windows = new WindowManager(ctx.logger);
  windows.setMax(initial.maxWindows);

  const pet = new PetMenu(ctx.logger);

  const state = { ctx, store, windows, pet, syncIntegrations: () => {} };

  ctx.effect(() => registerTools(ctx, state), 'window-manager.tools');

  ctx.inject(['webServer'], (scope) => {
    scope.effect(() => registerRoutes(scope, state), 'window-manager.routes');

    // 跳转列表与桌宠菜单都依赖「本机可访问的路由地址」，放在 webServer 就绪之后。
    scope.effect(() => {
      let stopped = false;
      let installedEndpoint = '';

      const plainOrigin = () => {
        try {
          return String(scope.webServer.getOrigin?.() ?? '').replace(/\/+$/, '');
        } catch {
          return '';
        }
      };

      /** 按当前配置开/关两个外部入口。设置页保存后也会调它。 */
      const sync = () => {
        if (stopped) return;
        const current = store.get();
        const origin = plainOrigin();

        if (current.enableJumpList && origin) {
          const endpoint = `${origin}${ROUTE_SEGMENT}/windows`;
          if (endpoint !== installedEndpoint) {
            installedEndpoint = endpoint;
            void installJumpList({ endpointUrl: endpoint, logger: ctx.logger });
          }
        } else if (installedEndpoint) {
          installedEndpoint = '';
          void removeJumpList({ logger: ctx.logger });
        }

        if (current.enablePetMenu && origin) {
          pet.start({
            origin,
            openWindow: () => windows.open({ baseUrl: windowOrigin(scope), config: store.get() }),
          });
        } else {
          pet.stop();
        }
      };

      state.syncIntegrations = sync;
      // 首次同步延后一点：等 connection 服务就绪后再取认证地址。
      const timer = setTimeout(sync, 1500);
      timer.unref?.();

      return () => {
        stopped = true;
        clearTimeout(timer);
        state.syncIntegrations = () => {};
        pet.stop();
        void pet.unregister();
        if (installedEndpoint) {
          installedEndpoint = '';
          void removeJumpList({ logger: ctx.logger });
        }
      };
    }, 'window-manager.integrations');
  });

  ctx.inject(['systemPrompt'], (scope) => {
    scope.effect(
      () =>
        scope.systemPrompt.section({
          name: 'tool:window-manager',
          order: 175,
          text: PROMPT_TEXT,
        }),
      'window-manager.prompt',
    );
  });

  // 插件卸载/进程退出时按设置收掉窗口，避免留下孤儿浏览器进程。
  //
  // 这里**不能**用 `ctx.effect` 的清理函数：改配置会触发 Loader 重新加载本
  // 插件条目，清理函数照跑一遍，于是"保存设置"会把用户开着的窗口全关掉。
  // 清理函数只该做能安全重放的收尾（取消定时器、注销菜单）；真正要结束
  // 外部进程的动作挂在进程级退出钩子上，并且只挂一次。
  //
  // 钩子挂在 globalThis 上而不是模块作用域：热重载会重新求值本模块，模块级
  // 变量会归零，钩子就会被重复安装。读取的 store 也跟着更新，保证用的是
  // 最近一次加载的配置（closeOnExit 可能刚被改过）。
  const existing = globalThis[EXIT_HOOK];
  if (existing) {
    existing.store = store;
  } else {
    const holder = { store };
    globalThis[EXIT_HOOK] = holder;
    const shutdown = () => {
      if (holder.store.get().closeOnExit === false) return;
      killProfilesSync();
    };
    process.once('exit', shutdown);
    for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP']) process.once(signal, shutdown);
  }

  // 热重载后新实例的槽位表是空的，但桌面上的窗口还在：接回来，
  // 这样 window_list 与上限判断看到的是真实情况。
  void windows.adoptAll().catch(() => {});
}
